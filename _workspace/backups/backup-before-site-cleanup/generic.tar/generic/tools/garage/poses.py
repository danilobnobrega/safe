"""Poses for the MakeHuman default rig, as world directions (person faces -Y, +X is their left).
Spine numbering is top-down in this rig: spine05 = pelvis end, spine01 = chest."""
from people_lib import aim, aim_chain, rot

SPINE = ['spine05', 'spine04', 'spine03', 'spine02', 'spine01']
NECK = ['neck01', 'neck02', 'neck03']


def arm(rig, s, upper, lower, hand=None):
    aim_chain(rig, [f'upperarm01.{s}', f'upperarm02.{s}'], upper)
    aim_chain(rig, [f'lowerarm01.{s}', f'lowerarm02.{s}'], lower)
    if hand:
        aim(rig, f'wrist.{s}', hand)


def leg(rig, s, thigh, shin, foot=None):
    aim_chain(rig, [f'upperleg01.{s}', f'upperleg02.{s}'], thigh)
    aim_chain(rig, [f'lowerleg01.{s}', f'lowerleg02.{s}'], shin)
    if foot:
        aim(rig, f'foot.{s}', foot)


def typing(rig):
    """sitting on a chair, forearms on the keyboard, looking down at the screen"""
    leg(rig, 'L', (0.1, -1, -0.04), (0.02, -0.22, -1), (0.0, -1, -0.45))
    leg(rig, 'R', (-0.08, -1, -0.02), (-0.04, -0.12, -1), (0.0, -1, -0.45))
    aim_chain(rig, SPINE, (0, -0.16, 1))
    aim_chain(rig, NECK, (0, -0.22, 1))
    aim(rig, 'head', (0, -0.1, 1))
    arm(rig, 'L', (0.16, -0.42, -0.9), (-0.16, -1, 0.1), (-0.1, -1, -0.12))
    arm(rig, 'R', (-0.16, -0.42, -0.9), (0.16, -1, 0.1), (0.1, -1, -0.12))


def clipboard(rig):
    """standing, weight on one leg, clipboard held against the chest, looking over"""
    leg(rig, 'L', (0.04, -0.12, -1), (0.0, 0.08, -1))
    leg(rig, 'R', (-0.02, 0.02, -1), (0.0, 0.0, -1))
    aim_chain(rig, SPINE, (0.03, 0.02, 1))
    arm(rig, 'R', (-0.1, -0.35, -0.93), (0.4, -0.85, 0.3), (0.5, -0.8, 0.0))
    arm(rig, 'L', (0.1, 0.03, -1), (0.06, -0.2, -1))
    aim_chain(rig, NECK, (-0.04, -0.08, 1))
    rot(rig, 'head', 'Z', 30)
    rot(rig, 'head', 'X', 9)
