import * as THREE from 'three'

/**
 * Cursor lab: tune what moving the mouse FEELS like, before deciding what the cursor does in the
 * hero. The cursor leaves ink in a field (ping-pong render target): every frame the field fades
 * (memory), is dragged along the motion (smear) and gets a new stroke stamped from the last head
 * position to the new one. The head follows the mouse through a spring (weight / inertia), the
 * stroke width reacts to speed, and the field is shown through a threshold (edge), broken up by
 * grain (texture) and shaken by a re-seeded offset (jitter).
 */

type Params = {
  stiffness: number // spring pull toward the mouse (1 = glued to it)
  damping: number // how fast the spring's own motion dies (low = overshoot / wobble)
  size: number // stroke radius at rest, px
  speedSize: number // -1 thinner when fast (steven) .. +1 bigger when fast (noth.in)
  memory: number // s for the trace to fade to half
  smear: number // how much the trace is dragged along the motion
  edge: number // 0 soft glow .. 1 hard cut
  texture: number // grain eating into the stroke
  textureScale: number
  jitter: number // px
  jitterRate: number // re-seeds per second
  head: number // px of the dot at the head (0 = none)
  dark: number // 0 ink on paper, 1 chalk on dark
  hideCursor: number // 1 hides the system arrow
}

const DEFAULTS: Params = {
  stiffness: 0.35,
  damping: 0.75,
  size: 14,
  speedSize: 0.3,
  memory: 0.35,
  smear: 0.2,
  edge: 0.8,
  texture: 0.25,
  textureScale: 3,
  jitter: 0,
  jitterRate: 4,
  head: 0,
  dark: 0,
  hideCursor: 1,
}

/** starting points taken from the two sites' code — only approximations of their feel */
const PRESETS: Record<string, Partial<Params>> = {
  'noth.in-ish': {
    stiffness: 0.25, damping: 0.7, size: 22, speedSize: 0.9, memory: 0.9, smear: 0.6,
    edge: 1, texture: 0, jitter: 0, head: 0, dark: 0,
  },
  'steven-ish': {
    stiffness: 0.18, damping: 1, size: 6, speedSize: -0.6, memory: 0.08, smear: 0,
    edge: 0.85, texture: 0.55, textureScale: 5, jitter: 3, jitterRate: 4, head: 0, dark: 1,
  },
  default: DEFAULTS,
}

const SLIDERS: [keyof Params, string, number, number, number, string][] = [
  // key, label, min, max, step, hint
  ['stiffness', 'follow', 0.02, 1, 0.01, 'how tightly it chases the mouse'],
  ['damping', 'settle', 0.3, 1, 0.01, 'low = overshoots and wobbles'],
  ['size', 'size', 1, 80, 1, 'px at rest'],
  ['speedSize', 'speed → size', -1, 1, 0.05, '− thinner when fast · + bigger'],
  ['memory', 'memory', 0.02, 3, 0.01, 's for the trace to half-fade'],
  ['smear', 'smear', 0, 1, 0.01, 'trace dragged along the motion'],
  ['edge', 'edge', 0, 1, 0.01, 'soft glow … hard cut'],
  ['texture', 'texture', 0, 1, 0.01, 'grain eating the stroke'],
  ['textureScale', 'texture scale', 0.5, 12, 0.1, ''],
  ['jitter', 'jitter', 0, 20, 0.5, 'px of shake'],
  ['jitterRate', 'jitter rate', 0, 30, 1, 'shakes per second'],
  ['head', 'head dot', 0, 24, 1, 'px, 0 = none'],
]

const p: Params = { ...DEFAULTS, ...load() }

function load(): Partial<Params> {
  try {
    return JSON.parse(localStorage.getItem('cursorLab') ?? '{}')
  } catch {
    return {}
  }
}
function save(): void {
  try {
    localStorage.setItem('cursorLab', JSON.stringify(p))
  } catch {
    /* private window etc. */
  }
}

// ------------------------------------------------------------------ renderer + field
const canvas = document.getElementById('lab') as HTMLCanvasElement
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false })
const dpr = Math.min(window.devicePixelRatio, 2)
renderer.setPixelRatio(dpr)
let W = window.innerWidth
let H = window.innerHeight
renderer.setSize(W, H)

const rtOpts = { type: THREE.HalfFloatType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter }
let rtA = new THREE.WebGLRenderTarget(W * dpr, H * dpr, rtOpts)
let rtB = new THREE.WebGLRenderTarget(W * dpr, H * dpr, rtOpts)
const cam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1)
const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2))
const scene = new THREE.Scene()
scene.add(quad)
const VERT = 'varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }'

const stampMat = new THREE.ShaderMaterial({
  vertexShader: VERT,
  uniforms: {
    tPrev: { value: null },
    uRes: { value: new THREE.Vector2(W, H) },
    uA: { value: new THREE.Vector2() },
    uB: { value: new THREE.Vector2() },
    uRa: { value: 0 },
    uRb: { value: 0 },
    uFade: { value: 1 },
    uSmear: { value: new THREE.Vector2() },
  },
  fragmentShader: /* glsl */ `
    varying vec2 vUv;
    uniform sampler2D tPrev;
    uniform vec2 uRes, uA, uB, uSmear;
    uniform float uRa, uRb, uFade;
    void main() {
      // memory + smear: last frame's ink, faded, pulled along the motion
      float prev = texture2D(tPrev, vUv - uSmear / uRes).r * uFade;
      // the new stroke: a capsule from the last head position to this one, radius tapering
      vec2 px = vUv * uRes;
      vec2 ab = uB - uA;
      float t = clamp(dot(px - uA, ab) / max(dot(ab, ab), 1e-4), 0.0, 1.0);
      float r = mix(uRa, uRb, t);
      float d = length(px - (uA + ab * t));
      float ink = 1.0 - smoothstep(r * 0.55, r, d);
      gl_FragColor = vec4(max(prev, ink), 0.0, 0.0, 1.0);
    }`,
})

const showMat = new THREE.ShaderMaterial({
  vertexShader: VERT,
  uniforms: {
    tField: { value: null },
    uRes: { value: new THREE.Vector2(W, H) },
    uEdge: { value: 0.8 },
    uTexture: { value: 0 },
    uTexScale: { value: 3 },
    uJitter: { value: new THREE.Vector2() },
    uSeed: { value: 0 },
    uHead: { value: new THREE.Vector3() },
    uDark: { value: 0 },
  },
  fragmentShader: /* glsl */ `
    varying vec2 vUv;
    uniform sampler2D tField;
    uniform vec2 uRes, uJitter;
    uniform float uEdge, uTexture, uTexScale, uSeed, uDark;
    uniform vec3 uHead; // xy px, z radius
    float hash(vec2 p) { p = fract(p * vec2(123.34, 345.45)); p += dot(p, p + 34.345); return fract(p.x * p.y); }
    float vnoise(vec2 p) {
      vec2 i = floor(p), f = fract(p); vec2 u = f * f * (3.0 - 2.0 * f);
      return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
    }
    void main() {
      vec2 px = vUv * uRes;
      float v = texture2D(tField, (px - uJitter) / uRes).r;
      // grain: fine noise + a coarser one, re-seeded with the jitter so it "boils" at the same rate
      vec2 q = px / (40.0 / uTexScale) + uSeed * 17.0;
      float grain = vnoise(q) * 0.6 + vnoise(q * 3.1) * 0.4;
      v -= uTexture * grain * 0.9;
      // edge: soft glow (wide ramp) ... hard cut (a pixel)
      float w = mix(0.5, 0.004, uEdge);
      float a = smoothstep(0.5 - w, 0.5 + w, v);
      // head dot
      a = max(a, 1.0 - smoothstep(uHead.z - 1.0, uHead.z, length(px - uHead.xy)));
      vec3 paper = vec3(0.937, 0.933, 0.906);
      vec3 ink = vec3(0.07);
      vec3 bg = mix(paper, vec3(0.07), uDark);
      vec3 fg = mix(ink, paper, uDark);
      gl_FragColor = vec4(mix(bg, fg, a), 1.0);
    }`,
})

// ------------------------------------------------------------------ head physics
const mouse = new THREE.Vector2(W / 2, H / 2)
const head = new THREE.Vector2(W / 2, H / 2)
const vel = new THREE.Vector2()
const last = new THREE.Vector2(W / 2, H / 2)
let lastR = 0
let seedT = 0
let seed = 0
const jitter = new THREE.Vector2()
let seen = false
window.addEventListener('pointermove', (e) => {
  mouse.set(e.clientX, H - e.clientY)
  if (!seen) {
    head.copy(mouse)
    last.copy(mouse)
    seen = true
  }
})

const clock = new THREE.Clock()
function frame(): void {
  const dt = Math.min(clock.getDelta(), 1 / 30)
  // spring toward the mouse: follow = its natural frequency, settle = damping ratio
  // (1 = critically damped, no overshoot; lower = overshoots and wobbles). Sub-stepped so a
  // stiff spring stays stable at low frame rates
  const omega = p.stiffness * 60
  if (p.stiffness >= 0.999) {
    head.copy(mouse)
    vel.set(0, 0)
  } else {
    const n = 4
    const h = dt / n
    for (let i = 0; i < n; i++) {
      vel.x += (omega * omega * (mouse.x - head.x) - 2 * p.damping * omega * vel.x) * h
      vel.y += (omega * omega * (mouse.y - head.y) - 2 * p.damping * omega * vel.y) * h
      head.x += vel.x * h
      head.y += vel.y * h
    }
  }

  const moved = head.clone().sub(last)
  const speed = moved.length() / Math.max(dt, 1e-4) // px/s
  const r = seen ? Math.max(0.5, p.size * THREE.MathUtils.clamp(1 + p.speedSize * (speed / 1200), 0.1, 4)) : 0
  if (lastR === 0) lastR = r

  // jitter + grain seed, re-rolled jitterRate times a second
  seedT += dt
  if (p.jitterRate > 0 && seedT > 1 / p.jitterRate) {
    seedT = 0
    seed = Math.random()
    jitter.set((Math.random() - 0.5) * 2 * p.jitter, (Math.random() - 0.5) * 2 * p.jitter)
  }

  // stamp
  const su = stampMat.uniforms
  su.tPrev.value = rtA.texture
  su.uA.value.copy(last)
  su.uB.value.copy(head)
  su.uRa.value = seen ? lastR : 0
  su.uRb.value = r
  su.uFade.value = Math.pow(0.5, dt / Math.max(p.memory, 0.001))
  su.uSmear.value.copy(moved).multiplyScalar(p.smear)
  quad.material = stampMat
  renderer.setRenderTarget(rtB)
  renderer.render(scene, cam)
  ;[rtA, rtB] = [rtB, rtA]

  // show
  const sh = showMat.uniforms
  sh.tField.value = rtA.texture
  sh.uEdge.value = p.edge
  sh.uTexture.value = p.texture
  sh.uTexScale.value = p.textureScale
  sh.uJitter.value.copy(jitter)
  sh.uSeed.value = seed
  sh.uHead.value.set(head.x, head.y, seen ? p.head : 0)
  sh.uDark.value = p.dark
  quad.material = showMat
  renderer.setRenderTarget(null)
  renderer.render(scene, cam)

  last.copy(head)
  lastR = r
  document.body.classList.toggle('nocursor', p.hideCursor > 0.5)
  requestAnimationFrame(frame)
}
requestAnimationFrame(frame)

window.addEventListener('resize', () => {
  W = window.innerWidth
  H = window.innerHeight
  renderer.setSize(W, H)
  rtA.setSize(W * dpr, H * dpr)
  rtB.setSize(W * dpr, H * dpr)
  stampMat.uniforms.uRes.value.set(W, H)
  showMat.uniforms.uRes.value.set(W, H)
})

// ------------------------------------------------------------------ panel
const panel = document.getElementById('panel')!
function buildPanel(): void {
  panel.innerHTML = '<h1>cursor lab</h1>'
  const groups: Record<string, (keyof Params)[]> = {
    weight: ['stiffness', 'damping'],
    stroke: ['size', 'speedSize'],
    trace: ['memory', 'smear'],
    surface: ['edge', 'texture', 'textureScale', 'jitter', 'jitterRate', 'head'],
  }
  for (const [g, keys] of Object.entries(groups)) {
    const h = document.createElement('div')
    h.className = 'group'
    h.textContent = g
    panel.appendChild(h)
    for (const key of keys) {
      const [, label, min, max, step, hint] = SLIDERS.find((s) => s[0] === key)!
      const l = document.createElement('label')
      l.innerHTML =
        `<span>${label}</span><span class="v">${p[key]}</span>` +
        `<input type="range" min="${min}" max="${max}" step="${step}" value="${p[key]}">` +
        (hint ? `<span class="hint">${hint}</span>` : '')
      const input = l.querySelector('input')!
      const val = l.querySelector('.v')!
      input.addEventListener('input', () => {
        p[key] = Number(input.value)
        val.textContent = input.value
        save()
      })
      panel.appendChild(l)
    }
  }
  const view = document.createElement('div')
  view.className = 'group'
  view.textContent = 'view'
  panel.appendChild(view)
  for (const [key, label] of [
    ['dark', 'chalk on dark'],
    ['hideCursor', 'hide system arrow'],
  ] as [keyof Params, string][]) {
    const c = document.createElement('label')
    c.className = 'check'
    c.innerHTML = `<input type="checkbox" ${p[key] > 0.5 ? 'checked' : ''}> ${label}`
    c.querySelector('input')!.addEventListener('change', (e) => {
      p[key] = (e.target as HTMLInputElement).checked ? 1 : 0
      save()
    })
    panel.appendChild(c)
  }
  const presets = document.createElement('div')
  presets.className = 'group'
  presets.textContent = 'start from'
  panel.appendChild(presets)
  const row = document.createElement('div')
  row.className = 'row'
  for (const name of Object.keys(PRESETS)) {
    const b = document.createElement('button')
    b.textContent = name
    b.addEventListener('click', () => {
      Object.assign(p, DEFAULTS, PRESETS[name])
      save()
      buildPanel()
    })
    row.appendChild(b)
  }
  const copy = document.createElement('button')
  copy.textContent = 'show values'
  copy.addEventListener('click', () => {
    let t = panel.querySelector('textarea')
    if (!t) {
      t = document.createElement('textarea')
      panel.appendChild(t)
    }
    t.value = JSON.stringify(p)
    t.select()
  })
  row.appendChild(copy)
  panel.appendChild(row)
}
buildPanel()
