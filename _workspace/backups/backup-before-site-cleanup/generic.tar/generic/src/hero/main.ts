import './hero.css'
import { ShaderHero } from './ShaderHero'
import { mountCookieBanner } from '../ui/cookieBanner'

const canvas = document.querySelector<HTMLCanvasElement>('#webgl')
if (!canvas) throw new Error('no #webgl canvas')

const hero = new ShaderHero(canvas, { crumbScale: 2 })
mountCookieBanner(hero.crumbs, () => hero.unlock())

// DEV ONLY — add ?dev=approach to the URL to skip straight to the ending instead
// of replaying the whole thing every time. Remove alongside ShaderHero.jumpToApproach
// once that stops being useful.
if (new URLSearchParams(location.search).get('dev') === 'approach') hero.jumpToApproach()
