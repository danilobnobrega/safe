import './hero.css'
import { ShaderHero } from './ShaderHero'
import { mountCookieBanner } from '../ui/cookieBanner'

// TEST route: /hero-letters, but falling through the wormhole lands on the garage page
// instead of the chapter tunnel
const canvas = document.querySelector<HTMLCanvasElement>('#webgl')
if (!canvas) throw new Error('no #webgl canvas')

const hero = new ShaderHero(canvas, {
  crumbScale: 2,
  revealLetters: true,
  weAreDodge: true,
  crumbPush: true,
  sign: 'matte',
  wormTo: `${import.meta.env.BASE_URL}garage.html`,
})
mountCookieBanner(hero.crumbs, () => hero.unlock())
