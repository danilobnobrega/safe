import './hero.css'
import { ShaderHero } from './ShaderHero'
import { mountCookieBanner } from '../ui/cookieBanner'

// TEST route: the hero with the reveal holes showing the wordmark in other bodies
// (LetterSwap) instead of the video
const canvas = document.querySelector<HTMLCanvasElement>('#webgl')
if (!canvas) throw new Error('no #webgl canvas')

const hero = new ShaderHero(canvas, { crumbScale: 2, revealLetters: true, weAreDodge: true, crumbPush: true, sign: 'matte' })
mountCookieBanner(hero.crumbs, () => hero.unlock())
