import * as THREE from 'three'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js'
import gsap from 'gsap'
import { registerChunks } from './chunks'
import { makeGlobals } from './materials'
import { GarageRoom } from './GarageRoom'
import { Post } from './Post'
import { EasedMouse } from './Mouse'
import { Inspect } from './Inspect'
import { ScanFocus } from './Scan'

const BASE = `${import.meta.env.BASE_URL}garage/`

/**
 * The garage page: the GENERIC office-in-a-garage drawn in chalk on #121212, with a photo ring
 * and a reflective floor — the render pipeline follows steven.com /creator-media (dark theme);
 * see GarageRoom (passes) and Post (screen chain). On top of it, GENERIC's own "scanner":
 *   entrance  the room is scanned into existence, top to bottom (intro)
 *   hover     the cursor is a scanner beam in the drawing + target brackets on objects (Inspect)
 *   click     fly to the object, lock on, scan it, type out why it's there (Scan)
 */
export class Garage {
  private renderer: THREE.WebGLRenderer
  private size = { width: 1, height: 1, pixelRatio: 1 }
  private camera: THREE.PerspectiveCamera
  private cameraMirror: THREE.PerspectiveCamera
  private mouse = new EasedMouse()
  private clock = new THREE.Clock()
  private delta = 0 // seconds * 100, capped at 1/30 s — the original's time unit
  private elapsed = 0
  private room?: GarageRoom
  private post?: Post
  private globals?: ReturnType<typeof makeGlobals>
  private inspect?: Inspect
  private focus?: ScanFocus
  private introBusy = true
  // TEST ?arrive=fall | ?arrive=ring: landing here out of the hero's wormhole (it jumps over at
  // its white peak). The page starts on that white and the fall carries on into the room:
  //   fall  still spinning and dropping, decelerating into the resting frame as the scan runs
  //   ring  spiralling down through the photo ring and landing in the room, the scan plane
  //         following the camera down
  private arrive = new URLSearchParams(location.search).get('arrive')
  private arrival = { k: 1 }
  private arrivalLook = new THREE.Vector3()
  private basePos = new THREE.Vector3()
  private lookTmp = new THREE.Vector3()
  private beamLast = new THREE.Vector2(-9, -9)
  private parallax = 0 // scroll-driven in the original; the page doesn't scroll yet
  private scrollMultiply = 1

  constructor(canvas: HTMLCanvasElement) {
    registerChunks()
    this.readSize()
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      powerPreference: 'high-performance',
      alpha: true,
      precision: 'highp',
      antialias: false,
      depth: false,
      stencil: false,
    })
    this.renderer.setPixelRatio(this.size.pixelRatio)
    this.renderer.setSize(this.size.width, this.size.height)
    this.renderer.setClearColor(0x000000, 0)

    this.camera = new THREE.PerspectiveCamera(this.fov(), this.size.width / this.size.height, 0.1, 100)
    this.camera.position.set(0, 0.91, 3.6)
    this.camera.layers.enable(2)
    this.cameraMirror = this.camera.clone()
    this.cameraMirror.layers.disable(2) // dark theme: the drawings are not reflected

    window.addEventListener('resize', this.onResize)
    if (this.arrive === 'fall' || this.arrive === 'ring') {
      // the hero's white flash, carried over: covers the load, then lifts
      const white = document.createElement('div')
      white.id = 'arrive-white'
      white.setAttribute('style', 'position:fixed;inset:0;background:#fff;z-index:10;pointer-events:none;transition:opacity .6s ease-out')
      document.body.appendChild(white)
    }
    void this.load()
  }

  private readSize(): void {
    const w = window.innerWidth
    const h = window.innerHeight
    this.size = { width: w, height: h, pixelRatio: Math.min(window.devicePixelRatio, w > 768 ? 1.5 : 2) }
  }

  private fov(): number {
    return this.size.width >= 768 ? 67 : 80
  }

  private async load(): Promise<void> {
    const tl = new THREE.TextureLoader()
    const tex = (name: string, repeatNearest = false) =>
      tl.loadAsync(BASE + name).then((t) => {
        t.colorSpace = THREE.NoColorSpace // shaders read raw values
        if (repeatNearest) {
          t.wrapS = t.wrapT = THREE.RepeatWrapping
          t.minFilter = t.magFilter = THREE.NearestFilter
          t.generateMipmaps = false
        } else {
          t.anisotropy = this.renderer.capabilities.getMaxAnisotropy()
        }
        return t
      })

    const draco = new DRACOLoader().setDecoderPath(`${import.meta.env.BASE_URL}draco/`)
    const gltf = new GLTFLoader().setDRACOLoader(draco)

    const [drawing, noise, concrete, photos, model] = await Promise.all([
      tex('drawing.png', true),
      tex('noise.png', true),
      tex('concrete.png', true),
      tex('photos.jpg'),
      gltf.loadAsync(BASE + 'garage.glb'),
    ])

    this.globals = makeGlobals({ drawing, noise })
    this.room = new GarageRoom(this.renderer, this.globals, this.size, { photos, concrete })
    this.room.setModel(model.scene)
    this.post = new Post(this.renderer, this.size, { noise })

    const inspect = (this.inspect = new Inspect(this.room.sceneDefault))
    const focus = (this.focus = new ScanFocus(this.globals, inspect))
    document.addEventListener('click', () => {
      if (focus.active) focus.close()
      else if (inspect.current) focus.open(inspect.current, this.camera, this.basePos)
    })
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') focus.close()
    })

    this.intro()
    this.renderer.setAnimationLoop(this.frame)
  }

  /**
   * The entrance: the room is scanned into existence. A plane sweeps down from above the photo
   * ring to the floor (fast through the ring, slowing over the set); only what's above it exists,
   * freshly scanned strokes come out orange, the floor appears as the plane reaches it; then the
   * orange settles to chalk. One gesture, with a slight push in. The post chain sits at its
   * resting values throughout.
   */
  private intro(): void {
    const s = this.post!.shared
    s.VIGNETTE_STRENGTH.value = 0.68
    s.BLUR_CENTER_POWER.value = 4
    s.BLUR_STRENGTH.value = 25
    s.DISTORTION_STRENGTH.value = 0
    s.CHROMATIC_ABBERATION_STRENGTH.value = 3.5
    s.CHROMATIC_ABBERATION_POWER.value = 8
    s.BARREL_DISTORT_STRENGTH.value = 0
    s.BLOOM_INTENSITY.value = 0.6

    const g = this.globals!
    g.REVEAL_ON.value = 1
    g.REVEAL_Y.value = 18 // above the highest photo the camera can see (far side of the ring)
    if (this.arrive === 'fall' || this.arrive === 'ring') return this.introArrive()
    gsap.to(this.camera.position, { z: 3, duration: 4, delay: 0.3, ease: 'power2.out' })
    gsap.to(g.REVEAL_Y, {
      value: -0.05,
      duration: 3.2,
      delay: 0.4,
      ease: 'power2.out',
      onComplete: () => {
        gsap.to(g.REVEAL_ON, {
          value: 0,
          duration: 0.9,
          ease: 'power1.inOut',
          onComplete: () => (this.introBusy = false),
        })
      },
    })
  }

  /** ?arrive=…: the wormhole's fall continues into the room, decelerating to the resting frame */
  private introArrive(): void {
    const g = this.globals!
    const ring = this.arrive === 'ring'
    const dur = ring ? 4.6 : 3.4
    const white = document.getElementById('arrive-white')
    requestAnimationFrame(() => white && (white.style.opacity = '0'))
    setTimeout(() => white?.remove(), 1200)
    this.arrival.k = 0
    gsap.to(this.arrival, { k: 1, duration: dur, ease: ring ? 'power2.out' : 'power3.out' })
    // the scan sweeps down ahead of the camera (in 'ring', fast enough that the spiral passes
    // through photos that are already there)
    const done = () =>
      gsap.to(g.REVEAL_ON, { value: 0, duration: 0.9, ease: 'power1.inOut', onComplete: () => (this.introBusy = false) })
    gsap.to(g.REVEAL_Y, { value: -0.05, duration: ring ? 2.2 : 3.0, ease: ring ? 'power1.out' : 'power2.out', onComplete: done })
  }

  /** camera pose along the arrival, k 0 -> 1 (eased); lands exactly on the resting pose */
  private poseArrival(k: number, ax: number, ay: number): void {
    const cam = this.camera
    const rest = this.arrivalLook.set(ax, 0.8 + ay + this.parallax, 0)
    if (this.arrive === 'ring') {
      const a = (1 - k) * Math.PI * 2.5 // a turn and a quarter around the set, unwinding
      const r = THREE.MathUtils.lerp(7.5, 3, k)
      const y = THREE.MathUtils.lerp(17, 0.91 - this.parallax * 2, k)
      cam.position.set(Math.sin(a) * r, y, Math.cos(a) * r)
      // looking across the ring (the photo walls fill the view) and a little down, levelling
      // out onto the set as it lands
      cam.lookAt(THREE.MathUtils.lerp(0, rest.x, k), THREE.MathUtils.lerp(y - 1.8, rest.y, k), 0)
      cam.rotateZ((1 - k) * (1 - k) * 0.9)
    } else {
      cam.position.set(0, THREE.MathUtils.lerp(3.2, 0.91 - this.parallax * 2, k), THREE.MathUtils.lerp(9, 3, k))
      cam.lookAt(rest)
      cam.rotateZ((1 - k) * (1 - k) * 2.6) // the wormhole's roll, still unwinding
    }
  }

  private frame = (): void => {
    const room = this.room
    const post = this.post
    const g = this.globals
    const inspect = this.inspect
    const f = this.focus
    if (!room || !post || !g || !inspect || !f) return
    this.delta = Math.min(this.clock.getDelta(), 1 / 30) * 100
    this.elapsed = this.clock.getElapsedTime()

    // update (order as the original: room, eased mouse, camera + mirror)
    room.update(this.elapsed)
    g.uTime.value = this.elapsed
    this.mouse.update(this.delta)
    const ax = this.mouse.normalized.x * 0.1 * this.scrollMultiply
    const ay = this.mouse.normalized.y * 0.1 * this.scrollMultiply
    if (this.arrival.k < 1) {
      this.poseArrival(this.arrival.k, ax, ay)
      this.basePos.copy(this.camera.position)
    } else if (f.t.value > 0) {
      // flying to / at a clicked object: from the room pose to the object's, the mouse look
      // fading out on the way
      const k = f.t.value
      this.camera.position.lerpVectors(this.basePos, f.pos, k)
      this.camera.position.y += Math.sin(Math.PI * k) * 0.5 // arc over the set, not through it
      this.lookTmp.set(ax, 0.8 + ay + this.parallax, 0).lerp(f.look, k)
      this.camera.lookAt(this.lookTmp)
    } else {
      this.camera.lookAt(ax, 0.8 + ay + this.parallax, 0)
      this.camera.position.y = 0.91 - this.parallax * 2
      this.basePos.copy(this.camera.position)
    }
    this.cameraMirror.position.copy(this.camera.position)
    this.cameraMirror.position.y *= -1
    this.cameraMirror.rotation.copy(this.camera.rotation)
    this.cameraMirror.rotation.z = -this.camera.rotation.z
    this.cameraMirror.rotation.x = -this.camera.rotation.x
    this.cameraMirror.rotation.y = this.camera.rotation.y

    // brackets + click scan: pinned on the clicked object through the flight and while there;
    // on the way back, nothing until the camera is home
    inspect.pinned = f.active
    inspect.enabled = !this.introBusy && (!!f.active || f.t.value === 0)
    this.camera.updateMatrixWorld()
    inspect.extraPad = f.lock.value
    inspect.update(this.camera)
    f.update()
    const u = post.pass0.uniforms
    u.uShade.value = f.shade.value
    u.uShadeRect.value.copy(f.shadeRect)
    u.uShade2.value += ((inspect.labelShown ? 1 : 0) - u.uShade2.value) * 0.2 // under the hover label
    u.uShadeRect2.value.copy(inspect.labelRect)
    document.body.style.cursor = inspect.current || f.active ? 'pointer' : ''

    // the beam's trail: the head always sits on the cursor; a new point is dropped whenever it
    // has moved far enough, and every point fades (~0.7 s)
    g.BEAM_ASPECT.value = this.size.width / this.size.height
    const on = !this.introBusy && f.t.value === 0 ? 1 : 0
    g.BEAM_ON.value += (on - g.BEAM_ON.value) * 0.1
    const pts = g.BEAM.value
    const fade = Math.exp(-this.delta / 100 / 0.7)
    for (const p of pts) p.z *= fade
    const x = this.mouse.normalized1.x * 0.5 + 0.5
    const y = this.mouse.normalized1.y * 0.5 + 0.5
    if (Math.hypot(x - this.beamLast.x, y - this.beamLast.y) > 0.03) {
      pts.unshift(pts.pop()!.set(x, y, 1))
      this.beamLast.set(x, y)
    } else pts[0].set(x, y, 1)

    // render
    room.renderPipeline(this.camera, this.cameraMirror)
    post.render(room.rtDefault.texture, room.rtBloom.texture)
  }

  private onResize = (): void => {
    this.readSize()
    this.renderer.setPixelRatio(this.size.pixelRatio)
    this.renderer.setSize(this.size.width, this.size.height)
    this.camera.aspect = this.size.width / this.size.height
    this.camera.fov = this.fov()
    this.camera.updateProjectionMatrix()
    this.cameraMirror.aspect = this.camera.aspect
    this.cameraMirror.fov = this.camera.fov
    this.cameraMirror.updateProjectionMatrix()
    this.room?.resize(this.size)
    this.post?.resize(this.size)
  }
}
